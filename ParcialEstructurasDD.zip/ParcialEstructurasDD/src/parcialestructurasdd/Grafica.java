package parcialestructurasdd;

import java.util.*;

public class Grafica {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Lista lista = new Lista();
        Pila pila = new Pila();
        Fila fila = new Fila();
        ArbolBinario arbol = new ArbolBinario();

        while (true) {
            System.out.println("1. Ingresar valor\n2. Mostrar lista\n3. Mostrar pila\n4. Mostrar fila\n5. Mostrar árbol binario\n6. Salir");
            int opcion = scanner.nextInt();

            if (opcion == 1) {
                System.out.print("Ingrese un valor: ");
                int valor = scanner.nextInt();
                lista.agregar(valor);
                pila.agregar(valor);
                fila.agregar(valor);
                arbol.agregar(valor);
            } else if (opcion == 2) {
                lista.mostrarGrafico();
            } else if (opcion == 3) {
                pila.mostrarGrafico();
            } else if (opcion == 4) {
                fila.mostrarGrafico();
            } else if (opcion == 5) {
                arbol.mostrarGrafico();
            } else if (opcion == 6) {
                System.out.println("Saliendo del programa...");
                break;
            } else {
                System.out.println("Opción inválida, intente de nuevo.");
            }
        }

        scanner.close();
    }
}
