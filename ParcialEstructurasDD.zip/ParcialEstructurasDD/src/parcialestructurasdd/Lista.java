package parcialestructurasdd;


import java.util.*;

public class Lista {
    private final List<Integer> elementos = new ArrayList<>();

    public void agregar(int valor) {
        elementos.add(valor);
    }

    public List<Integer> obtenerElementos() {
        return new ArrayList<>(elementos);
    }

    public void mostrarGrafico() {
        new GraficoLista(elementos, "Lista").mostrar();
    }
}
