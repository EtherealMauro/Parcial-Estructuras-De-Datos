package parcialestructurasdd;

import java.util.*;

public class Pila {
    private final Stack<Integer> pila = new Stack<>();

    public void agregar(int valor) {
        pila.push(valor);
    }

    public List<Integer> obtenerElementos() {
        List<Integer> elementos = new ArrayList<>(pila);
        Collections.reverse(elementos);
        return elementos;
    }

    public void mostrarGrafico() {
        new GraficoLista(obtenerElementos(), "Pila").mostrar();
    }
}
