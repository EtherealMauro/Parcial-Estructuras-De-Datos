package parcialestructurasdd;

import java.util.*;

public class Fila {
    private final Queue<Integer> fila = new LinkedList<>();

    public void agregar(int valor) {
        fila.add(valor);
    }

    public List<Integer> obtenerElementos() {
        return new ArrayList<>(fila);
    }

    public void mostrarGrafico() {
        new GraficoLista(obtenerElementos(), "Fila").mostrar();
    }
}
