package parcialestructurasdd;

import javax.swing.*;
import java.awt.*;

public class ArbolBinario extends JPanel {
    private Nodo raiz;

    public void agregar(int valor) {
        raiz = agregarRecursivo(raiz, valor);
    }

    private Nodo agregarRecursivo(Nodo actual, int valor) {
        if (actual == null) {
            return new Nodo(valor);
        }
        if (valor < actual.valor) {
            actual.izquierdo = agregarRecursivo(actual.izquierdo, valor);
        } else if (valor > actual.valor) {
            actual.derecho = agregarRecursivo(actual.derecho, valor);
        }
        return actual;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        dibujarArbol(g, getWidth() / 2, 30, raiz, getWidth() / 4);
    }

    private void dibujarArbol(Graphics g, int x, int y, Nodo nodo, int espacio) {
        if (nodo != null) {
            g.drawOval(x - 15, y - 15, 30, 30);
            g.drawString(String.valueOf(nodo.valor), x - 5, y + 5);
            if (nodo.izquierdo != null) {
                g.drawLine(x, y, x - espacio, y + 50);
                dibujarArbol(g, x - espacio, y + 50, nodo.izquierdo, espacio / 2);
            }
            if (nodo.derecho != null) {
                g.drawLine(x, y, x + espacio, y + 50);
                dibujarArbol(g, x + espacio, y + 50, nodo.derecho, espacio / 2);
            }
        }
    }

    public void mostrarGrafico() {
        JFrame frame = new JFrame("Árbol Binario");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
