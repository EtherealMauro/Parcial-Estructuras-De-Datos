package parcialestructurasdd;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class GraficoLista extends JPanel {
    private final List<Integer> elementos;
    private final String titulo;

    public GraficoLista(List<Integer> elementos, String titulo) {
        this.elementos = elementos;
        this.titulo = titulo;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int x = 20;
        for (int valor : elementos) {
            g.drawRect(x, 50, 50, 50);
            g.drawString(String.valueOf(valor), x + 20, 80);
            x += 60;
        }
    }

    public void mostrar() {
        JFrame frame = new JFrame(titulo);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(this);
        frame.setSize(800, 200);
        frame.setVisible(true);
    }
}
